package Mensaje;

import java.io.Serializable;

public class MensajeConfConexion extends Mensaje implements Serializable{

	public MensajeConfConexion(int tipo, String or, String des) {
		super(tipo, or, des);
	}

}
