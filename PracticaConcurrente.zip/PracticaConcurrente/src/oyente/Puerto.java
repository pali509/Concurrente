package oyente;

public class Puerto {
	private int puerto;
	public Puerto() {
		puerto = 889;
	}
	public void incrementar() {
		puerto++;
	}
	public int getPuerto() {
		return puerto;
	}
}
